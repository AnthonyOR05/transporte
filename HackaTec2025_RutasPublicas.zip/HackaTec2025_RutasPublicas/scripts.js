// Cambiar la función loadRoutes por:
async function loadRoutes() {
    try {
        const response = await fetch('/api/rutas');
        if (!response.ok) throw new Error('Error al cargar rutas');
        return await response.json();
    } catch (error) {
        console.error("Error:", error);
        return [];
    }
}